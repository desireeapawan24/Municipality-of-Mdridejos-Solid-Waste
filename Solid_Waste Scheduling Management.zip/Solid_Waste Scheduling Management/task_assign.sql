CREATE TABLE waste_collection_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    truck_id INT NOT NULL,
    assign_day VARCHAR(10) NOT NULL,
    collection_date DATE NOT NULL,
    area VARCHAR(255) NOT NULL,
    waste_type VARCHAR(255) NOT NULL,
    driver_id INT NOT NULL,
    status ENUM('pending', 'cancelled', 'in-progress', 'completed') DEFAULT 'pending',
    FOREIGN KEY (truck_id) REFERENCES collector_trucks(id),
    FOREIGN KEY (driver_id) REFERENCES waste_collectors(id)
);
