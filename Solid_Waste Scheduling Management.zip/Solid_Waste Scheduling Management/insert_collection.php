<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connection.php';

$truck_id = $_POST['truck_id'] ?? '';
$assign_day = $_POST['assign_day'] ?? '';
$collection_date = $_POST['collection_date'] ?? '';
$area = $_POST['area'] ?? '';
$waste_type = $_POST['waste_type'] ?? '';
$driver_id = $_POST['driver_id'] ?? '';

if (empty($truck_id) || empty($assign_day) || empty($collection_date) || empty($area) || empty($waste_type) || empty($driver_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing required data']);
    exit;
}

try {
    // Prepare the SQL query to insert the assignment
    $sql = "INSERT INTO waste_collection_assignments (truck_id, assign_day, collection_date, area, waste_type, driver_id) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Error preparing statement']);
        exit;
    }

    // Bind parameters to prevent SQL injection
    $stmt->bind_param("issssi", $truck_id, $assign_day, $collection_date, $area, $waste_type, $driver_id);

    // Execute the query
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Collection assignment successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error executing query: ' . $stmt->error]);
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
