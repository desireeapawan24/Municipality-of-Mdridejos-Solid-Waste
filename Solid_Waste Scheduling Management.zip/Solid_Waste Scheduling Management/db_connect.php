<?php
// Database connection settings
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root"; // Your MySQL username (default is 'root' in XAMPP)
$password = ""; // Your MySQL password (default is empty in XAMPP)
$dbname = "nan"; // The name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
