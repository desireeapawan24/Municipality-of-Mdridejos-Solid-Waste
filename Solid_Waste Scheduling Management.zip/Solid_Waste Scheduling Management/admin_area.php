<?php
// Include database connection
include 'db_connection.php';

// Function to get all areas from the database
function getAllAreas($conn) {
    $sql = "SELECT * FROM waste_areas ORDER BY area_name ASC";
    $result = $conn->query($sql);
    return $result;
}

// Function to get all schedules from the database
function getAllSchedules($conn) {
    $sql = "SELECT * FROM waste_collections ORDER BY collection_date ASC";
    $result = $conn->query($sql);
    return $result;
}

// Function to create a new area
function createArea($conn, $areaName, $description) {
    $sql = "INSERT INTO waste_areas (area_name, description) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $areaName, $description);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}

// Function to assign a schedule to an area
function assignScheduleToArea($conn, $areaId, $scheduleId) {
    $sql = "INSERT INTO area_schedules (area_id, schedule_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $areaId, $scheduleId);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}

// Handle form submissions for creating areas and assigning schedules
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_area'])) {
        $areaName = $_POST['area_name'];
        $description = $_POST['description'];
        $success = createArea($conn, $areaName, $description);
    }

    if (isset($_POST['assign_schedule'])) {
        $areaId = $_POST['area_id'];
        $scheduleId = $_POST['schedule_id'];
        $successAssignment = assignScheduleToArea($conn, $areaId, $scheduleId);
    }
}

// Fetch existing areas and schedules
$areas = getAllAreas($conn);
$schedules = getAllSchedules($conn);

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waste Collection Areas</title>
    <style>
        /* Styling for the body */
        body {
            background-color: #f0fff4;
            font-family: 'Arial', sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* Header Styling */
        .header {
            background-color: #38a169;
            color: white;
            padding: 15px 0;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
        }

        /* Form and Button Styling */
        form {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        input, select {
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            width: 50%;
            margin-bottom: 15px;
            font-size: 1rem;
        }

        input[type="date"] {
            padding: 8px 12px;
        }

        /* Button Styling */
        button {
            background-color: #38a169;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #2f855a;
        }

        /* Section Styling */
        section {
            padding: 20px;
            margin-bottom: 30px;
        }

        section h2 {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 15px;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #e2e8f0;
            text-align: left;
        }

        th {
            background-color: #38a169;
            color: white;
        }

        tr:hover {
            background-color: #f4fdf4;
        }

        /* Fixed Bottom Navigation */
        .fixed-bottom-nav {
            background-color: #38a169;
            color: white;
            display: flex;
            justify-content: space-around;
            padding: 12px;
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        .fixed-bottom-nav button {
            font-size: 1rem;
            font-weight: bold;
            padding: 8px 12px;
            background-color: transparent;
            color: white;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .fixed-bottom-nav button:hover {
            background-color: #2f855a;
        }

        /* SweetAlert Customization */
        .swal2-popup {
            font-size: 1rem;
            font-family: 'Arial', sans-serif;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .header {
                font-size: 1.2rem;
            }

            .fixed-bottom-nav {
                padding: 8px;
            }

            .fixed-bottom-nav button {
                font-size: 0.9rem;
                padding: 6px 10px;
            }
        }
    </style>
</head>
<body>

<div class="header">
    Waste Collection Areas
</div>

<section>
    <h2>View Existing Collection Areas</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Area Name</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $areas->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['area_name']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</section>

<section>
    <h2>Create New Collection Area</h2>
    <form method="POST">
        <label for="area_name">Area Name</label>
        <input type="text" id="area_name" name="area_name" required><br>

        <label for="description">Description</label>
        <textarea id="description" name="description" required></textarea><br>

        <button type="submit" name="create_area">Create Area</button>
    </form>
</section>

<section>
    <h2>Assign Schedule to Area</h2>
    <form method="POST">
        <label for="area_id">Select Area</label>
        <select id="area_id" name="area_id" required>
            <?php while ($area = $areas->fetch_assoc()) { ?>
                <option value="<?php echo $area['id']; ?>"><?php echo $area['area_name']; ?></option>
            <?php } ?>
        </select><br>

        <label for="schedule_id">Select Schedule</label>
        <select id="schedule_id" name="schedule_id" required>
            <?php while ($schedule = $schedules->fetch_assoc()) { ?>
                <option value="<?php echo $schedule['id']; ?>"><?php echo $schedule['collection_date'] . " " . $schedule['collection_time']; ?></option>
            <?php } ?>
        </select><br>

        <button type="submit" name="assign_schedule">Assign Schedule</button>
    </form>
</section>

<div class="fixed-bottom-nav">
    <button>Manage Areas</button>
    <button>Settings</button>
</div>

</body>
</html>
