<?php
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$pass = "";
$db = "nan"; // Replace with your actual database name

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['answer' => 'Database connection failed.']);
    exit;
}

function getBotResponse($question, $conn) {
    $question = strtolower(trim($question));

    // Example logic – replace/add more cases here
    if (strpos($question, 'hello') !== false || strpos($question, 'hi') !== false) {
        return "Hello! How can I help you today?";
    } elseif (strpos($question, 'how many drivers') !== false) {
        $sql = "SELECT COUNT(*) as total_drivers FROM waste_collectors WHERE role = 'Driver'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return "There are " . $row['total_drivers'] . " drivers.";
        } else {
            return "No drivers found.";
        }
    } elseif (strpos($question, 'how many collectors') !== false) {
        $sql = "SELECT COUNT(*) as total_collectors FROM waste_collectors WHERE role = 'Collector'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return "There are " . $row['total_collectors'] . " collectors.";
        } else {
            return "No collectors found.";
        }
    } elseif (strpos($question, 'how many absent') !== false) {
        $sql = "SELECT COUNT(*) as total_absent FROM collector_attendance WHERE status = 'Absent' AND attendance_date = CURDATE()";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return "There are " . $row['total_absent'] . " absent today.";
        } else {
            return "No collectors are absent today.";
        }
    } elseif (strpos($question, 'how many present today') !== false) {
        $sql = "SELECT COUNT(*) as total_present FROM collector_attendance WHERE status = 'Present' AND attendance_date = CURDATE()";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return "There are " . $row['total_present'] . " present today.";
        } else {
            return "No collectors are present today.";
        }
    } elseif (strpos($question, 'who are the present collectors or drivers today') !== false) {
        $sql = "SELECT full_name FROM waste_collectors WHERE id IN (SELECT collector_id FROM collector_attendance WHERE status = 'Present' AND attendance_date = CURDATE())";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $response = "Present collectors and drivers today:\n";
            while ($row = $result->fetch_assoc()) {
                $response .= $row['full_name'] . "\n";
            }
            return nl2br($response);
        } else {
            return "No collectors or drivers are present today.";
        }
    } elseif (strpos($question, 'where is the area scheduled today') !== false) {
        $sql = "SELECT area FROM waste_collection_assignments WHERE collection_date = CURDATE()";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $response = "Scheduled areas for waste collection today:\n";
            while ($row = $result->fetch_assoc()) {
                $response .= $row['area'] . "\n";
            }
            return nl2br($response);
        } else {
            return "No waste collection areas scheduled for today.";
        }
    } elseif (strpos($question, 'how many schedules today') !== false) {
        $sql = "SELECT COUNT(*) as total_schedules FROM waste_collection_assignments WHERE collection_date = CURDATE()";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return "There are " . $row['total_schedules'] . " schedules for today.";
        } else {
            return "No schedules for today.";
        }
    } elseif (strpos($question, 'what is solid waste collection') !== false) {
        return "Solid waste collection is the process of gathering and transporting waste materials, such as garbage and recyclables, from households or businesses to designated disposal or recycling sites.";
    }

    return "Sorry, I couldn't understand that.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['question'])) {
    $question = $_POST['question'];
    $answer = getBotResponse($question, $conn);
    echo json_encode(['answer' => $answer]);
} else {
    echo json_encode(['answer' => 'Invalid request.']);
}
?>
