<?php
include 'db_connection.php';

// Fetch all drivers from the waste_collectors table (role = 'Driver')
$sqlDrivers = "SELECT * FROM waste_collectors WHERE role = 'Driver'";
$resultDrivers = $conn->query($sqlDrivers);
$drivers = [];
if ($resultDrivers->num_rows > 0) {
    while ($row = $resultDrivers->fetch_assoc()) {
        $drivers[] = $row;
    }
}

// Fetch all trucks from the trucks table
$sqlTrucks = "SELECT * FROM collector_trucks";
$resultTrucks = $conn->query($sqlTrucks);
$trucks = [];
if ($resultTrucks->num_rows > 0) {
    while ($row = $resultTrucks->fetch_assoc()) {
        $trucks[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Waste Collection Assignment</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background-color: #e6f7e6;
      font-family: 'Arial', sans-serif;
    }
    .container {
      background-color: #ffffff;
      border-radius: px;
      padding: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
     
    }
    .btn-primary {
      background-color: #28a745;
      border-color: #28a745;
    }
    .btn-primary:hover {
      background-color: #218838;
      border-color: #1e7e34;
    }
    .form-label {
      font-weight: bold;
    }
    .header {
      color: #28a745;
      text-align: center;
      font-size: 2rem;
      margin-bottom: 20px;
    }
    .footer {
      background-color: #28a745;
      color: white;
      text-align: center;
      padding: 10px;
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
    }
    .color-indicator {
      height: 20px;
      width: 100px;
      margin-top: 10px;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <div class="header">Assign Waste Collection</div>
  <form id="collectionForm">
    <div class="mb-3">
      <label for="truck_id" class="form-label">Select Truck</label>
      <select class="form-select" id="truck_id" name="truck_id" required>
        <option value="">Select a Truck</option>
        <?php foreach ($trucks as $truck): ?>
          <option value="<?= $truck['id'] ?>"><?= $truck['truck_number'] ?> - <?= $truck['plate_number'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="area" class="form-label">Area</label>
      <input type="text" class="form-control" id="area" name="area" required>
    </div>

    <div class="mb-3">
      <label for="waste_type" class="form-label">Waste Type</label>
      <input type="text" class="form-control" id="waste_type" name="waste_type" required>
    </div>

    <div class="mb-3">
      <label for="driver_id" class="form-label">Assign Driver</label>
      <select class="form-select" id="driver_id" name="driver_id" required>
        <option value="">Select a Driver</option>
        <?php foreach ($drivers as $driver): ?>
          <option value="<?= $driver['id'] ?>"><?= $driver['full_name'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="assign_day_display" class="form-label">Assign Day</label>
      <input type="text" class="form-control" id="assign_day_display" disabled>
      <input type="hidden" id="assign_day" name="assign_day">
    </div>

    <div class="mb-3">
      <label for="collection_date" class="form-label">Collection Date</label>
      <input type="date" class="form-control" id="collection_date" name="collection_date" required>
    </div>

    <div class="mb-3">
      <label for="color_indicator" class="form-label">Assigned Color for the Day</label>
      <div id="color_indicator" class="color-indicator"></div>
    </div>

    <button type="submit" class="btn btn-primary">Assign Collection</button>
  </form>
</div>
<script>
document.getElementById("collection_date").addEventListener("change", function () {
  const date = new Date(this.value);
  const day = date.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  const assignDayDisplay = document.getElementById("assign_day_display");
  const assignDayHidden = document.getElementById("assign_day");
  const colorIndicator = document.getElementById("color_indicator");

  if ([1, 3, 5].includes(day)) {
    assignDayDisplay.value = "MWF";
    assignDayHidden.value = "MWF";
    colorIndicator.style.backgroundColor = "#FFEB3B"; // Yellow
  } else if ([2, 4, 6].includes(day)) {
    assignDayDisplay.value = "TTHS";
    assignDayHidden.value = "TTHS";
    colorIndicator.style.backgroundColor = "#03A9F4"; // Blue
  } else {
    assignDayDisplay.value = "";
    assignDayHidden.value = "";
    colorIndicator.style.backgroundColor = "#ffffff"; // White
  }
});

document.getElementById("collectionForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const truckId = document.getElementById("truck_id").value;
  const assignDay = document.getElementById("assign_day").value;
  const collectionDate = document.getElementById("collection_date").value;
  const area = document.getElementById("area").value;
  const wasteType = document.getElementById("waste_type").value;
  const driverId = document.getElementById("driver_id").value;

  // ✅ Frontend validation
  if (!truckId || !assignDay || !collectionDate || !area || !wasteType || !driverId) {
    Swal.fire("Error", "Please fill in all required fields", "error");
    return;
  }

  console.log("Checking truck availability...");

  fetch("check_truck_availability.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `truck_id=${encodeURIComponent(truckId)}&collection_date=${encodeURIComponent(collectionDate)}`
  })
    .then(res => res.json())
    .then(data => {
      console.log("Truck availability result:", data);

      if (!data.success) {
        Swal.fire("Unavailable", data.message || "Truck is not available on this date.", "error");
      } else {
        // ✅ Proceed to insert
        console.log("Inserting assignment...");

        fetch("insert_collection.php", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: `truck_id=${encodeURIComponent(truckId)}&assign_day=${encodeURIComponent(assignDay)}&collection_date=${encodeURIComponent(collectionDate)}&area=${encodeURIComponent(area)}&waste_type=${encodeURIComponent(wasteType)}&driver_id=${encodeURIComponent(driverId)}`
        })
          .then(res => res.json())
          .then(data => {
            console.log("Insert result:", data);
            if (data.success) {
              Swal.fire("Success", data.message || "Collection assigned successfully.", "success");
              document.getElementById("collectionForm").reset();
              document.getElementById("assign_day_display").value = "";
              document.getElementById("color_indicator").style.backgroundColor = "#ffffff";
            } else {
              Swal.fire("Error", data.message || "Failed to assign collection.", "error");
            }
          })
          .catch(error => {
            console.error("Insert Error:", error);
            Swal.fire("Error", "An unexpected error occurred during assignment.", "error");
          });
      }
    })
    .catch(error => {
      console.error("Availability Check Error:", error);
      Swal.fire("Error", "An unexpected error occurred while checking truck availability.", "error");
    });
});
</script>


</body>
</html>
