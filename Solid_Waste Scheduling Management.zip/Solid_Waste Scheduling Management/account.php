<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: log_in.php");
    exit();
}

include 'db.php';
$full_name = $_SESSION['full_name']; // Retrieve full name from session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: rgba(228, 75, 75, 0.9);
            color: #fff;
            padding-top: 50px;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 12px;
            display: inline-block;
        }
        .logout-btn, .crud-btn {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            background-color: rgba(33, 9, 247, 0.95);
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            border: none;
            transition: 0.3s;
            margin: 5px;
        }
        .logout-btn:hover, .crud-btn:hover {
            background-color: rgb(18, 204, 236);
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            color: black;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        th {
            background-color: rgb(209, 67, 65);
            color: white;
        }
        .crud-container {
    position: relative;
    width: 100%;
    padding: 20px;
}

.crud-btn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: rgba(33, 9, 247, 0.95);
    color: white;
    padding: 12px 20px;
    border-radius: 50px;
    font-size: 16px;
    cursor: pointer;
    border: none;
    transition: 0.3s;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
}

.crud-btn:hover {
    background-color: rgb(18, 204, 236);
}

        .edit-btn {
            background-color: rgb(65, 101, 209);
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        .edit-btn:hover {
            background-color: darkblue;
        }
        .delete-btn {
            background-color: red;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        .delete-btn:hover {
            background-color: darkred;
        }
        .logout-container {
            margin-top: 40px;
        }
    </style>
</head>
<body>

    

    <div class="crud-container">
        <h3>User Management</h3>
        <button class="crud-btn" onclick="showAddUserModal()">Add User</button>
        <div id="userList"></div>
    </div>

    <!-- Logout Button at the Bottom -->
    

    <script>
        function confirmLogout() {
            Swal.fire({
                title: "Are you sure?",
                text: "You will be logged out of your account.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#ff2d55",
                cancelButtonColor: "#555",
                confirmButtonText: "Yes, Logout",
                cancelButtonText: "Cancel"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "logout.php";
                }
            });
        }

        function loadUsers() {
            $.ajax({
                url: "fetch_users.php",
                type: "GET",
                success: function(data) {
                    $("#userList").html(data);
                }
            });
        }

        function showAddUserModal() {
            Swal.fire({
                title: "Add User",
                html: `
                    <input type="text" id="swal-full_name" class="swal2-input" placeholder="Full Name">
                    <input type="email" id="swal-email" class="swal2-input" placeholder="Email">
                    <input type="text" id="swal-address" class="swal2-input" placeholder="Address">
                    <select id="swal-gender" class="swal2-input">
                        <option value="" disabled selected>Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                    <input type="text" id="swal-contact_number" class="swal2-input" placeholder="Contact Number">
                    <input type="date" id="swal-birthdate" class="swal2-input">
                `,
                confirmButtonText: "Add User",
                preConfirm: () => {
                    return {
                        full_name: document.getElementById("swal-full_name").value,
                        email: document.getElementById("swal-email").value,
                        address: document.getElementById("swal-address").value,
                        gender: document.getElementById("swal-gender").value,
                        contact_number: document.getElementById("swal-contact_number").value,
                        birthdate: document.getElementById("swal-birthdate").value
                    };
                }
            }).then((result) => {
                if (result.value) {
                    $.post("add_user.php", result.value, function(response) {
                        if (response.status === "success") {
                            Swal.fire("Added!", "User has been added.", "success");
                            loadUsers();
                        } else {
                            Swal.fire("Error!", response.message, "error");
                        }
                    }, "json");
                }
            });
        }

        function editUser(userId) {
            $.get("get_user.php", { id: userId }, function(user) {
                if (user) {
                    Swal.fire({
                        title: "Edit User",
                        html: `
                            <input type="text" id="swal-full_name" class="swal2-input" value="${user.full_name}">
                            <input type="email" id="swal-email" class="swal2-input" value="${user.email}">
                            <input type="text" id="swal-address" class="swal2-input" value="${user.address}">
                            <select id="swal-gender" class="swal2-input">
                                <option value="Male" ${user.gender === "Male" ? "selected" : ""}>Male</option>
                                <option value="Female" ${user.gender === "Female" ? "selected" : ""}>Female</option>
                            </select>
                            <input type="text" id="swal-contact_number" class="swal2-input" value="${user.contact_number}">
                            <input type="date" id="swal-birthdate" class="swal2-input" value="${user.birthdate}">
                        `,
                        confirmButtonText: "Update",
                        preConfirm: () => {
                            return {
                                id: userId,
                                full_name: document.getElementById("swal-full_name").value,
                                email: document.getElementById("swal-email").value,
                                address: document.getElementById("swal-address").value,
                                gender: document.getElementById("swal-gender").value,
                                contact_number: document.getElementById("swal-contact_number").value,
                                birthdate: document.getElementById("swal-birthdate").value
                            };
                        }
                    }).then((result) => {
                        if (result.value) {
                            $.post("edit_user.php", result.value, function(response) {
                                if (response.status === "success") {
                                    Swal.fire("Updated!", "User details updated.", "success");
                                    loadUsers();
                                } else {
                                    Swal.fire("Error!", response.message, "error");
                                }
                            }, "json");
                        }
                    });
                }
            }, "json");
        }function deleteUser(id) {
    Swal.fire({
        title: "Are you sure?",
        text: "This action cannot be undone!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes, delete it!"
    }).then((result) => {
        if (result.isConfirmed) {
            $.post("delete_user.php", { id: id }, function(response) {
                if (response.success) {
                    Swal.fire("Deleted!", "User has been deleted.", "success");
                    loadUsers();
                } else {
                    Swal.fire("Error!", response.error, "error");
                }
            }, "json").fail(function() {
                Swal.fire("Error!", "Failed to delete user.", "error");
            });
        }
    });
}


        setInterval(loadUsers, 5000);
        $(document).ready(loadUsers);

        setInterval(loadUsers, 5000);
        $(document).ready(loadUsers);
    </script>

</body>
</html>
