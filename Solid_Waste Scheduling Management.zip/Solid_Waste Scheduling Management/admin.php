<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Municipality of Madridejos Solid Waste Management System Scheduling</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background-color: #f0fff4;
    }
    .header {
      background-color: #38a169;
      color: white;
      width: 100%;
    }
    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      bottom: 0;
      width: 14rem;
      background-color: #276749;
      color: white;
      display: flex;
      flex-direction: column;
      padding-top: 1rem;
      overflow-y: auto;
      z-index: 1;
    }
    .sidebar a {
      display: block;
      padding: 0.75rem 1rem;
      border-bottom: 1px solid #2f855a;
      color: white;
      cursor: pointer;
    }
    .sidebar a:hover {
      background-color: #2f855a;
    }
    .sidebar .toggle-btn {
  position: absolute;
  top: 1rem;
  right: -1.5rem;
  background-color: #38a169;
  color: white;
  padding: 0.5rem; /* Adjust padding as needed */
  border-radius: 50%;
  cursor: pointer;
  height: 1rem; /* Set the height of the button */
  width: 2.5rem;  /* Set the width of the button */
  display: flex;
  justify-content: center;
  align-items: center;
}

    iframe {
      margin-left: 16rem;
      width: calc(100% - 16rem);
      height: calc(100vh - 4rem);
      border: none;
      position: relative;
      overflow: auto; /* Ensures iframe content scrolls */
    }
    .logout-button {
      background-color: #e53e3e;
      color: white;
      padding: 1rem;
      width: 100%;
      text-align: center;
      cursor: pointer;
    }
    .logout-button:hover {
      background-color: #c53030;
    }
    .ai-button-container {
      position: absolute;
      top: 10px;
      right: 10px;
      z-index: 2;
    }
  </style>
</head>
<body class="font-sans">
  <div class="flex h-screen">
    <!-- Sidebar -->
    <nav class="sidebar">
      <h2 class="text-2xl font-semibold mb-4 text-center">Admin</h2>
      <a onclick="loadPage('dash.php')">Dashboard</a>
      <a onclick="loadPage('admin_sched.php')">Schedule Management</a>
      <a onclick="loadPage('admin_com.php')">Schedules</a>
      <a onclick="loadPage('admin_task.php')">Today Schedule</a>
      <a onclick="loadPage('admin_collec.php')">Employee Management</a>
      <a onclick="loadPage('sala.php')">Salary Management</a>
      <a onclick="loadPage('admin_collect_sched.php')">Attendance</a>
      <a onclick="loadPage('admin_atten.php')">Attendance Record</a>
      <a onclick="loadPage('truck.php')">Truck Management</a>
     
      <!-- Logout Button at the bottom of the sidebar -->
      <div class="mt-auto">
        <div class="logout-button" onclick="confirmLogout()">🔒 Logout</div>
      </div>
    </nav>

    <!-- Main Content Area -->
    <div class="flex-1 relative">
  

      <!-- AI Button positioned in the upper-right corner -->
      <div class="ai-button-container">
        <button onclick="loadPage('chatbot.php')" class="bg-green-500 text-white p-3 rounded-full shadow-md hover:bg-green-600">
          Chat AI
        </button>
      </div>
      <iframe id="contentFrame" src="dash.php"></iframe>
    </div>
  </div>

  <script>
    function loadPage(page) {
      document.getElementById('contentFrame').src = page;
    }

    function confirmLogout() {
      Swal.fire({
        title: 'Are you sure?',
        text: "You will be logged out!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, logout!',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#e53e3e',
        cancelButtonColor: '#4CAF50',
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = 'logout.php';
        }
      });
    }
  </script>
</body>
</html>
