<?php
include 'db.php';

$result = $conn->query("SELECT id, full_name, email, address, gender, contact_number, birthdate, age FROM users");

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Full Name</th><th>Email</th><th>Address</th><th>Gender</th><th>Contact</th><th>Birthdate</th><th>Age</th><th>Actions</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['address']) . "</td>";
        echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
        echo "<td>" . htmlspecialchars($row['contact_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['birthdate']) . "</td>";
        echo "<td>" . htmlspecialchars($row['age']) . "</td>"; // Display age
        echo "<td>
                <button class='edit-btn' onclick='editUser(" . $row['id'] . ")'>Edit</button>
                <button class='delete-btn' onclick='deleteUser(" . $row['id'] . ")'>Delete</button>
              </td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No users found.</p>";
}

$conn->close();
?>
