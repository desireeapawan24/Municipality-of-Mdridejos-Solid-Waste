CREATE TABLE waste_collectors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100),
    contact_number VARCHAR(20),
    email VARCHAR(100),
    assign ENUM('MWF', 'TTHS') NOT NULL,  -- The schedule (MWF or TTHS)
    role ENUM('Driver', 'Collector') NOT NULL,
    start_work_date DATE NOT NULL         -- Date when the worker started
);
