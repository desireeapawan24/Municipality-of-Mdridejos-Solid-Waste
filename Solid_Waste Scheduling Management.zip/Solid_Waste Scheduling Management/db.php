<?php
$servername = "localhost";  // Change if using a different host
$username = "root";         // Default XAMPP MySQL username
$password = "";             // Default XAMPP MySQL password (empty)
$database = "nan";  // Replace with your actual database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
