<?php
// Include database connection file
include 'db_connection.php';

// Function to get the count of scheduled collections
function getScheduledCollectionsCount($conn) {
    $sql = "SELECT COUNT(*) AS scheduled_count FROM collections WHERE status = 'Scheduled'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['scheduled_count'];
}

// Function to get the count of missed collections
function getMissedCollectionsCount($conn) {
    $sql = "SELECT COUNT(*) AS missed_count FROM collections WHERE status = 'Missed'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['missed_count'];
}

// Function to get the task completion rate
function getTaskCompletionRate($conn) {
    $sql = "SELECT COUNT(*) AS total_tasks, SUM(status = 'Completed') AS completed_tasks FROM collections";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if ($row['total_tasks'] > 0) {
        return round(($row['completed_tasks'] / $row['total_tasks']) * 100, 2);
    }
    return 0; // Avoid division by zero
}

// Get data from the database
$scheduledCount = getScheduledCollectionsCount($conn);
$missedCount = getMissedCollectionsCount($conn);
$completionRate = getTaskCompletionRate($conn);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <style>
    /* Your CSS code here (same as previously shared) */
  </style>
</head>
<body>
  <div class="header">
    Dashboard
  </div>

  <section>
    <h2>Overview</h2>
    <p>Here are some key stats:</p>
    <div class="stats-container">
      <div class="stat">
        <h3>Scheduled Collections</h3>
        <p><?php echo $scheduledCount; ?></p>
      </div>
      <div class="stat">
        <h3>Missed Collections</h3>
        <p><?php echo $missedCount; ?></p>
      </div>
      <div class="stat">
        <h3>Task Completion Rate</h3>
        <p><?php echo $completionRate; ?>%</p>
      </div>
    </div>
  </section>

  <section>
    <h2>Task List</h2>
    <table>
      <thead>
        <tr>
          <th>Task</th>
          <th>Status</th>
          <th>Scheduled Date</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Fetch task list from the database
        $sql = "SELECT * FROM collections ORDER BY scheduled_date DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
          echo "<tr>
                  <td>Collection " . $row['id'] . "</td>
                  <td>" . $row['status'] . "</td>
                  <td>" . $row['scheduled_date'] . "</td>
                </tr>";
        }
        ?>
      </tbody>
    </table>
  </section>

  <div class="fixed-bottom-nav">
    <button>Home</button>
    <button>Settings</button>
    <button>Help</button>
  </div>
</body>
</html>
