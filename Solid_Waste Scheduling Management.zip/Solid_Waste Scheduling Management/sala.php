<?php
// Include the database connection
include 'db_connect.php';

// Fetch all collectors from the database
$sql = "SELECT id, full_name FROM waste_collectors";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Collector Salary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9f7ef;
            color: #2f6d4e;
            padding: 20px;
        }

        h2 {
            color: #4caf50;
            text-align: center;
        }

        .form-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        label {
            font-size: 1.2em;
            margin-bottom: 5px;
            display: block;
        }

        input[type="number"], input[type="date"], input[type="submit"], select {
            width: 90%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #d1e7d1;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #81c784;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #66bb6a;
        }
    </style>
</head>
<body>

    <h2>Add Collector Salary</h2>

    <div class="form-container">
        <form action="insert_salary.php" method="POST">
            <label for="collector_id">Collector Name:</label>
            <select id="collector_id" name="collector_id" required>
                <option value="">Select Collector</option>
                <?php
                // Display the list of collectors as options
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['full_name'] . "</option>";
                    }
                } else {
                    echo "<option value=''>No collectors found</option>";
                }
                ?>
            </select>

            <label for="salary">Salary:</label>
            <input type="number" id="salary" name="salary" step="0.01" required>


            <input type="submit" value="Add Salary">
        </form>
    </div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
