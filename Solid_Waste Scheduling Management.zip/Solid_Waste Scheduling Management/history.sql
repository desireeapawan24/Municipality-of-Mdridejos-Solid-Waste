CREATE TABLE waste_collection_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    schedule_id INT NOT NULL,  -- Foreign key to link to original schedule in waste_collections
    collection_date DATE NOT NULL,
    collection_time TIME NOT NULL,
    area VARCHAR(255) NOT NULL,
    waste_type VARCHAR(100) NOT NULL,
    is_recurring BOOLEAN DEFAULT FALSE,  -- True if the collection is recurring
    recurrence_type ENUM('None', 'Weekly', 'Monthly') DEFAULT 'None',  -- Recurrence type
    status ENUM('pending', 'cancelled', 'in-progress', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Record the time this entry was created
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- Timestamp for updates
    FOREIGN KEY (schedule_id) REFERENCES waste_collections(id) ON DELETE CASCADE
);