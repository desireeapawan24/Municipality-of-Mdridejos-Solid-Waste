<?php
include 'db_connect.php';

$resultMessage = '';
$isSuccess = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $collector_id = $_POST['collector_id'];
    $salary = $_POST['salary'];

    function insertOrUpdateSalary($collector_id, $salary) {
        global $conn, $resultMessage, $isSuccess;

        // Check if collector already has a salary
        $check_sql = "SELECT id FROM collector_salaries WHERE collector_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $collector_id);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            // Update salary
            $update_sql = "UPDATE collector_salaries SET salary = ? WHERE collector_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("di", $salary, $collector_id);
            if ($update_stmt->execute()) {
                $resultMessage = "Salary updated successfully!";
                $isSuccess = true;
            } else {
                $resultMessage = "Error updating salary: " . $update_stmt->error;
            }
            $update_stmt->close();
        } else {
            // Insert new salary
            $insert_sql = "INSERT INTO collector_salaries (collector_id, salary) VALUES (?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("id", $collector_id, $salary);
            if ($insert_stmt->execute()) {
                $resultMessage = "Salary inserted successfully!";
                $isSuccess = true;
            } else {
                $resultMessage = "Error inserting salary: " . $insert_stmt->error;
            }
            $insert_stmt->close();
        }

        $check_stmt->close();
    }

    insertOrUpdateSalary($collector_id, $salary);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add or Update Collector Salary</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9f7ef;
            color: #2f6d4e;
            padding: 20px;
        }
        h2 {
            color: #4caf50;
            text-align: center;
        }
        .form-container {
            max-width: 600px;
            margin: auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold;
        }
        select, input[type="number"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background-color: #81c784;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #66bb6a;
        }
    </style>
</head>
<body>

<h2>Add or Update Collector Salary</h2>

<div class="form-container">
    <form action="insert_salary.php" method="POST">
        <label for="collector_id">Collector:</label>
        <select id="collector_id" name="collector_id" required>
            <option value="">-- Select Collector --</option>
            <?php
            $result = $conn->query("SELECT id, full_name FROM waste_collectors ORDER BY full_name ASC");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id']}'>{$row['full_name']}</option>";
            }
            ?>
        </select>

        <label for="salary">Salary Amount:</label>
        <input type="number" step="0.01" name="salary" id="salary" required>

        <input type="submit" value="Save Salary">
    </form>
</div>

<?php if (!empty($resultMessage)): ?>
<script>
Swal.fire({
    icon: '<?php echo $isSuccess ? "success" : "error"; ?>',
    title: '<?php echo $isSuccess ? "Success" : "Error"; ?>',
    text: '<?php echo $resultMessage; ?>',
    timer: 2000,
    showConfirmButton: true
}).then(() => {
    window.location.href = 'insert_salary.php';
});
</script>
<?php endif; ?>

</body>
</html>
