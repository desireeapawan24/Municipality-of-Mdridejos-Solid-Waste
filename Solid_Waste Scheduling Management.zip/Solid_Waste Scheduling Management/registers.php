<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Registration</title>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&family=Poppins:wght@300;400&display=swap" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #a8e063, #56ab2f);
      font-family: 'Poppins', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      overflow: hidden;
    }

    .container {
      background: rgba(255, 255, 255, 0.95);
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0, 128, 0, 0.3);
      padding: 30px;
      width: 40%;
      min-width: 450px;
      max-width: 600px;
      max-height: 90vh;
      overflow-y: auto;
      text-align: center;
    }

    h2 {
      font-family: 'Merriweather', serif;
      color: #2e7d32;
      font-size: 30px;
      margin-bottom: 20px;
    }

    .form-group {
      text-align: left;
      margin-bottom: 15px;
    }

    .form-group label {
      font-size: 16px;
      font-weight: bold;
      color: #2e7d32;
      margin-bottom: 5px;
      display: block;
    }

    .form-group input, .form-group select {
      width: 90%;
      padding: 10px;
      border: 2px solid #66bb6a;
      border-radius: 8px;
      font-size: 16px;
      color: #333;
      background-color: #f9f9f9;
    }

    button {
      background-color: #43a047;
      color: #fff;
      padding: 12px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-size: 18px;
      width: 100%;
      margin-top: 15px;
      transition: background 0.3s ease;
    }

    button:hover {
      background-color: #388e3c;
    }

    .login-btn {
      background-color: transparent;
      color: #2e7d32;
      width: 90%;
      font-size: 16px;
      padding: 10px;
      border-radius: 8px;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      text-align: center;
      margin-top: 10px;
      transition: background-color 0.3s;
    }

    .login-btn:hover {
      background-color: rgba(76, 175, 80, 0.2);
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Student Registration</h2>
    <form action="registers_process.php" method="POST">
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" name="email" placeholder="Enter your school email" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" name="password" placeholder="Create a password" required>
      </div>
      <div class="form-group">
        <label for="full_name">Full Name:</label>
        <input type="text" name="full_name" placeholder="Enter your full name" required>
      </div>
      <div class="form-group">
        <label for="address">Address:</label>
        <input type="text" name="address" placeholder="Enter your address" required>
      </div>
      <div class="form-group">
        <label for="gender">Gender:</label>
        <select name="gender" required>
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="form-group">
        <label for="contact_number">Contact:</label>
        <input type="tel" id="contact_number" name="contact_number" placeholder="Enter contact number" required maxlength="11">
      </div>
      <div class="form-group">
        <label for="birthdate">Birthday:</label>
        <input type="date" id="birthdate" name="birthdate" required>
      </div>
      <div class="form-group">
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" placeholder="Age" readonly>
      </div>
      <button type="submit">Register</button>
    </form>
    <a href="log_in.php" class="login-btn">Already have an account? Login</a>
  </div>

  <script>
    document.getElementById("contact_number").addEventListener("input", function (event) {
      this.value = this.value.replace(/\D/g, '');
    });

    document.addEventListener("DOMContentLoaded", function () {
      const birthdateInput = document.getElementById("birthdate");
      const ageInput = document.getElementById("age");

      birthdateInput.addEventListener("input", function () {
        const birthdate = new Date(this.value);
        const today = new Date();
        let age = today.getFullYear() - birthdate.getFullYear();
        const monthDiff = today.getMonth() - birthdate.getMonth();
        const dayDiff = today.getDate() - birthdate.getDate();

        if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
          age--;
        }
        ageInput.value = age > 0 ? age : "";
      });
    });

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('error') === 'email_exists') {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'This email is already registered!'
      });
    } else if (urlParams.get('success') === 'registered') {
      Swal.fire({
        icon: 'success',
        title: 'Registration Successful!',
        text: 'You can now log in.'
      }).then(() => {
        window.location.href = "log_in.php";
      });
    }
  </script>
</body>
</html>
