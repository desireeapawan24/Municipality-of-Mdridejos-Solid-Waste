<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $contact_number = trim($_POST['contact_number']);
    $birthdate = trim($_POST['birthdate']);
    $gender = trim($_POST['gender']);
    $password = password_hash("defaultpassword", PASSWORD_DEFAULT); // Default password

    // Validate required fields
    if (empty($full_name) || empty($email) || empty($address) || empty($contact_number) || empty($birthdate) || empty($gender)) {
        echo json_encode(["status" => "error", "message" => "All fields are required"]);
        exit();
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Invalid email format"]);
        exit();
    }

    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();
    if ($checkStmt->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Email already exists"]);
        exit();
    }
    $checkStmt->close();

    // Calculate age from birthdate
    $birthdateObj = new DateTime($birthdate);
    $today = new DateTime();
    $age = $today->diff($birthdateObj)->y;

    // Insert user into database
    $stmt = $conn->prepare("INSERT INTO users (email, password, full_name, address, gender, contact_number, birthdate, age) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssi", $email, $password, $full_name, $address, $gender, $contact_number, $birthdate, $age);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User added successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add user"]);
    }

    $stmt->close();
    $conn->close();
}
?>
