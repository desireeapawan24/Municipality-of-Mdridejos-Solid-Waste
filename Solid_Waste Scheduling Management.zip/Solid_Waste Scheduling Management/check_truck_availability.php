<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connection.php';

$truck_id = $_POST['truck_id'] ?? '';
$collection_date = $_POST['collection_date'] ?? '';

if (empty($truck_id) || empty($collection_date)) {
    echo json_encode(['success' => false, 'message' => 'Missing required data']);
    exit;
}

try {
    $sql = "SELECT COUNT(*) as total FROM waste_collection_assignments WHERE truck_id = ? AND collection_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $truck_id, $collection_date);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ($result['total'] > 0) {
        echo json_encode(['success' => false, 'message' => 'Truck already assigned on this date.']);
    } else {
        echo json_encode(['success' => true]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
