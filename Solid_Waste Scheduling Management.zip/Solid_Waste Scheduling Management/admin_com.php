<?php
// Include database connection
include 'db_connection.php';

// Handle delete schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_schedule']) && isset($_POST['schedule_id'])) {
    $scheduleId = intval($_POST['schedule_id']);
    $deleteSql = "DELETE FROM waste_collection_assignments WHERE id = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param('i', $scheduleId);

    if ($stmt->execute()) {
        // Redirect to avoid POST re-submission and allow alert to show
        header("Location: ".$_SERVER['PHP_SELF']."?deleted=1&page=" . (isset($_GET['page']) ? $_GET['page'] : 1));
        exit;
    } else {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to delete the schedule.',
            });
        </script>";
    }
    $stmt->close();
}

// Function to get schedules with pagination
function getSchedulesWithPagination($conn, $limit, $offset) {
    $sql = "SELECT wca.id, ct.truck_number, wca.assign_day, wca.collection_date, wca.area, wca.waste_type, wc.full_name AS driver_name, wca.status
            FROM waste_collection_assignments wca
            JOIN collector_trucks ct ON wca.truck_id = ct.id
            JOIN waste_collectors wc ON wca.driver_id = wc.id
            ORDER BY wca.collection_date ASC LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $limit, $offset);
    $stmt->execute();
    return $stmt->get_result();
}

// Fetch total number of schedules
function getTotalSchedules($conn) {
    $sql = "SELECT COUNT(*) AS total FROM waste_collection_assignments";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}

// Pagination
$limit = 5;
$totalSchedules = getTotalSchedules($conn);
$totalPages = ceil($totalSchedules / $limit);
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch schedules
$schedules = getSchedulesWithPagination($conn, $limit, $offset);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedules Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #e8f5e9;
            margin: 0;
            padding: 20px;
        }

        .header {
            background-color: #43a047;
            color: white;
            text-align: center;
            padding: 20px 0;
            font-size: 28px;
            font-weight: bold;
            border-radius: 10px;
        }

        section {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        h2 {
            color: #2e7d32;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #388e3c;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f1f8e9;
        }

        tr:hover {
            background-color: #dcedc8;
        }

        .pagination {
            margin: 20px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .pagination button {
            padding: 8px 16px;
            background-color: #66bb6a;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .pagination button:disabled {
            background-color: #c8e6c9;
            cursor: not-allowed;
        }

        .delete-btn {
            background-color: #e53935;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 8px;
            cursor: pointer;
        }

        .delete-btn:hover {
            background-color: #c62828;
        }
    </style>
</head>
<body>

<?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Deleted!',
        text: 'Schedule has been deleted.',
        timer: 1500,
        showConfirmButton: false
    });
</script>
<?php endif; ?>

<div class="header">Schedules Management</div>

<section>
    <h2>View Existing Schedules</h2>

    <div class="pagination">
        <a href="?page=<?php echo max(1, $page - 1); ?>"><button <?php if ($page == 1) echo 'disabled'; ?>>← Previous</button></a>
        <a href="?page=<?php echo min($totalPages, $page + 1); ?>"><button <?php if ($page == $totalPages) echo 'disabled'; ?>>Next →</button></a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Truck Number</th>
                <th>Assign Day</th>
                <th>Collection Date</th>
                <th>Area</th>
                <th>Waste Type</th>
                <th>Driver Name</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $schedules->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['truck_number']; ?></td>
                    <td><?php echo $row['assign_day']; ?></td>
                    <td><?php echo $row['collection_date']; ?></td>
                    <td><?php echo $row['area']; ?></td>
                    <td><?php echo $row['waste_type']; ?></td>
                    <td><?php echo $row['driver_name']; ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td>
                        <form method="POST" id="deleteForm<?php echo $row['id']; ?>">
                            <input type="hidden" name="schedule_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="delete_schedule" value="1">
                            <button type="button" onclick="confirmDelete(<?php echo $row['id']; ?>)" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="pagination">
        <a href="?page=<?php echo max(1, $page - 1); ?>"><button <?php if ($page == 1) echo 'disabled'; ?>>Previous</button></a>
        <a href="?page=<?php echo min($totalPages, $page + 1); ?>"><button <?php if ($page == $totalPages) echo 'disabled'; ?>>Next</button></a>
    </div>
</section>

<script>
function confirmDelete(scheduleId) {
    Swal.fire({
        title: 'Are you sure?',
        text: 'You won’t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('deleteForm' + scheduleId).submit();
        }
    });
}
</script>

</body>
</html>
