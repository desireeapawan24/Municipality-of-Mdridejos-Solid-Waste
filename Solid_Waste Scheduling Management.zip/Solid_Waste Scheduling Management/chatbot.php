<?php
// Waste Collection Chatbot in one PHP file

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    header('Content-Type: application/json');

    $dbHost = 'localhost';
    $dbName = 'nan';
    $dbUser = 'root';
    $dbPass = '';

    try {
        $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
    } catch (PDOException $e) {
        echo json_encode(['reply' => "Oops! I can't connect to the database right now. Please try again later."]);
        exit;
    }

    $input = trim($_POST['message'] ?? '');
    $inputLower = strtolower($input);

    // Helper: Clean collector name
    function cleanName($name) {
        return ucwords(trim(preg_replace('/[^a-z\s]/i', '', $name)));
    }

    // Helper: Send response
    function respond($text) {
        return json_encode(['reply' => $text]);
    }

    // Extract collector name
    function extractCollectorName($text) {
        if (preg_match('/collector\s+([a-z\s]+)/i', $text, $m)) {
            return cleanName($m[1]);
        }
        return null;
    }

    // Extract date
    function extractDate($text) {
        if (preg_match('/(\d{4}-\d{2}-\d{2})/', $text, $m)) {
            return $m[1];
        }
        if (preg_match('/(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{4}/i', $text, $m)) {
            return $m[0];
        }
        return null;
    }

    try {
        if (strpos($inputLower, 'attendance') !== false) {
            $collector = extractCollectorName($input);
            $date = extractDate($inputLower);

            if ($collector && preg_match('/on\s+(\d{4}-\d{2}-\d{2})/', $inputLower, $dateMatch)) {
                $stmt = $pdo->prepare("
                    SELECT ca.status, ca.attendance_date
                    FROM collector_attendance ca
                    JOIN waste_collectors wc ON wc.id = ca.collector_id
                    WHERE wc.full_name = :name AND ca.attendance_date = :date
                    LIMIT 1
                ");
                $stmt->execute(['name' => $collector, 'date' => $dateMatch[1]]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    echo respond("On {$row['attendance_date']}, {$collector} was marked as {$row['status']}.");
                } else {
                    echo respond("I couldn't find attendance info for {$collector} on {$dateMatch[1]}.");
                }
                exit;
            } elseif ($collector && $date) {
                $dateObj = DateTime::createFromFormat('F Y', $date);
                if ($dateObj) {
                    $month = $dateObj->format('m');
                    $year = $dateObj->format('Y');

                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) as present_count
                        FROM collector_attendance ca
                        JOIN waste_collectors wc ON wc.id = ca.collector_id
                        WHERE wc.full_name = :name AND ca.status = 'Present' 
                          AND YEAR(ca.attendance_date) = :year AND MONTH(ca.attendance_date) = :month
                    ");
                    $stmt->execute(['name' => $collector, 'year' => $year, 'month' => $month]);
                    $count = $stmt->fetchColumn();

                    echo respond("Looks like {$collector} was present {$count} times in {$date}.");
                } else {
                    echo respond("Could you please specify the month and year for attendance?");
                }
                exit;
            } else {
                echo respond("Please tell me the collector's name and date to check attendance.");
                exit;
            }
        }

        if (strpos($inputLower, 'assignments') !== false && preg_match('/truck\s+([\w\-]+)/i', $input, $m)) {
            $truckNumber = strtoupper($m[1]);
            $stmt = $pdo->prepare("
                SELECT assign_day, collection_date, area, status
                FROM waste_collection_assignments wca
                JOIN collector_trucks ct ON ct.id = wca.truck_id
                WHERE ct.truck_number = :truck
                ORDER BY collection_date DESC
                LIMIT 5
            ");
            $stmt->execute(['truck' => $truckNumber]);
            $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($assignments) {
                $reply = "Here are recent assignments for truck {$truckNumber}:\n";
                foreach ($assignments as $a) {
                    $reply .= "- {$a['collection_date']} ({$a['assign_day']}): {$a['area']} - Status: {$a['status']}\n";
                }
                echo respond($reply);
            } else {
                echo respond("I couldn't find any assignments for truck {$truckNumber}.");
            }
            exit;
        }

        if (strpos($inputLower, 'salary') !== false) {
            $collector = extractCollectorName($input);
            if ($collector) {
                $stmt = $pdo->prepare("
                    SELECT cs.salary
                    FROM collector_salaries cs
                    JOIN waste_collectors wc ON wc.id = cs.collector_id
                    WHERE wc.full_name = :name
                ");
                $stmt->execute(['name' => $collector]);
                $salary = $stmt->fetchColumn();

                if ($salary) {
                    echo respond("The salary for {$collector} is ₱" . number_format($salary, 2) . ".");
                } else {
                    echo respond("Sorry, I couldn't find salary information for {$collector}.");
                }
            } else {
                echo respond("Please tell me which collector's salary you'd like to know.");
            }
            exit;
        }

        if (strpos($inputLower, 'truck') !== false || strpos($inputLower, 'trucks') !== false) {
            $stmt = $pdo->query("SELECT truck_number, plate_number FROM collector_trucks");
            $trucks = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($trucks) {
                $reply = "Here's a list of trucks and their plate numbers:\n";
                foreach ($trucks as $t) {
                    $reply .= "- {$t['truck_number']} (Plate: {$t['plate_number']})\n";
                }
                echo respond($reply);
            } else {
                echo respond("There are no trucks registered in the system.");
            }
            exit;
        }

        echo respond("Sorry, I didn't quite get that. You can ask me about collectors, attendance, truck assignments, or salaries.");
        exit;

    } catch (Exception $e) {
        echo respond("Oops! Something went wrong: " . $e->getMessage());
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Green-Themed Waste Collection Chatbot</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #e6f2e6;
      color: #155724;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }

    header {
      background: #28a745;
      color: white;
      padding: 1rem;
      text-align: center;
      font-weight: bold;
      font-size: 1.5rem;
    }

    main {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      max-width: 600px;
      margin: 1rem auto;
      background: #d4edda;
      border-radius: 8px;
      box-shadow: 0 0 10px #28a745aa;
      overflow: hidden;
    }

    #chat {
      flex-grow: 1;
      padding: 1rem;
      overflow-y: auto;
      border-bottom: 2px solid #28a745;
    }

    .message {
      max-width: 80%;
      margin-bottom: 1rem;
      padding: 0.75rem 1rem;
      border-radius: 20px;
      line-height: 1.4;
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    .user {
      background: #155724;
      color: #d4edda;
      margin-left: auto;
      border-bottom-right-radius: 0;
    }

    .bot {
      background: #c3e6cb;
      color: #155724;
      margin-right: auto;
      border-bottom-left-radius: 0;
    }

    #input-area {
      display: flex;
      border-top: 2px solid #28a745;
      background: #c3e6cb;
      padding: 0.5rem;
    }

    #message-input {
      flex-grow: 1;
      border: none;
      border-radius: 20px;
      padding: 0.75rem 1rem;
      font-size: 1rem;
    }
    #message-input:focus {
      outline: 2px solid #28a745;
    }

    button#send-btn {
      background: #28a745;
      color: white;
      border: none;
      border-radius: 20px;
      padding: 0 1.5rem;
      margin-left: 0.5rem;
      font-size: 1rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button#send-btn:hover {
      background: #218838;
    }

    #chat::-webkit-scrollbar {
      width: 8px;
    }
    #chat::-webkit-scrollbar-track {
      background: #d4edda;
    }
    #chat::-webkit-scrollbar-thumb {
      background: #28a745;
      border-radius: 4px;
    }

    @media (max-width: 640px) {
      main {
        margin: 0.5rem;
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
<header>Waste Collection Chatbot 💚</header>
<main>
  <div id="chat"></div>
  <form id="chat-form" autocomplete="off">
    <input type="text" id="message-input" placeholder="Ask me about collectors, attendance, trucks, etc." required />
    <button type="submit" id="send-btn">Send</button>
  </form>
</main>

<script>
  const chat = document.getElementById('chat');
  const form = document.getElementById('chat-form');
  const input = document.getElementById('message-input');

  function appendMessage(text, sender) {
    const msg = document.createElement('div');
    msg.className = 'message ' + sender;
    msg.textContent = text;
    chat.appendChild(msg);
    chat.scrollTop = chat.scrollHeight;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message) return;

    appendMessage(message, 'user');
    input.value = '';

    try {
      const res = await fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'message=' + encodeURIComponent(message),
      });
      const data = await res.json();
      appendMessage(data.reply, 'bot');
    } catch (err) {
      appendMessage("Sorry, something went wrong. Please try again.", 'bot');
    }
  });
</script>
</body>
</html>
