<?php
// Include database connection
include 'db_connection.php';

// SQL to create collector_trucks table
$sql = "CREATE TABLE IF NOT EXISTS collector_trucks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    truck_number VARCHAR(50) UNIQUE NOT NULL,
    plate_number VARCHAR(50) UNIQUE NOT NULL
)";

// Execute query to create the table
if ($conn->query($sql) === TRUE) {
    // Table created successfully
} else {
    echo "Error creating table: " . $conn->error;
}

// SQL to fetch all collector_trucks data
$fetchSql = "SELECT * FROM collector_trucks";
$result = $conn->query($fetchSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Collector Truck Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background-color: #e6f7e6; /* Lively green background */
      font-family: 'Arial', sans-serif;
    }
    .container {
      background-color: #ffffff;
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .btn-primary {
      background-color: #28a745;
      border-color: #28a745;
    }
    .btn-primary:hover {
      background-color: #218838;
      border-color: #1e7e34;
    }
    .form-label {
      font-weight: bold;
    }
    .header {
      color: #28a745;
      text-align: center;
      font-size: 2rem;
      margin-bottom: 20px;
    }
    .footer {
      background-color: #28a745;
      color: white;
      text-align: center;
      padding: 10px;
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
    }
    table {
      width: 100%;
      margin-top: 30px;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #28a745;
      color: white;
    }
  </style>
</head>
<body>

  <div class="container mt-5">
    <div class="header">Add Collector Truck</div>
    <form id="truckForm">
      <div class="mb-3">
        <label for="truck_number" class="form-label">Truck Number</label>
        <input type="text" class="form-control" id="truck_number" name="truck_number" required>
      </div>
      <div class="mb-3">
        <label for="plate_number" class="form-label">Plate Number</label>
        <input type="text" class="form-control" id="plate_number" name="plate_number" required>
      </div>
      <button type="submit" class="btn btn-primary">Add Truck</button>
    </form>

    <div class="mt-4">
      <h3>Existing Trucks</h3>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Truck Number</th>
            <th>Plate Number</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
              echo "<tr>
                      <td>" . $row['id'] . "</td>
                      <td>" . $row['truck_number'] . "</td>
                      <td>" . $row['plate_number'] . "</td>
                    </tr>";
            }
          } else {
            echo "<tr><td colspan='3'>No trucks found</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    document.getElementById("truckForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const truckNumber = document.getElementById("truck_number").value;
      const plateNumber = document.getElementById("plate_number").value;

      // Sending form data to the PHP backend using Fetch API
      fetch("insert_truck.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `truck_number=${encodeURIComponent(truckNumber)}&plate_number=${encodeURIComponent(plateNumber)}`
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          Swal.fire("Success", data.message, "success");
          document.getElementById("truckForm").reset();
          location.reload();  // Reload the page to update the truck list
        } else {
          Swal.fire("Error", data.message, "error");
        }
      })
      .catch(error => {
        console.error('Error:', error);
        Swal.fire("Error", "An unexpected error occurred.", "error");
      });
    });
  </script>

</body>
</html>
