<?php
// Include database connection
include 'db_connection.php';

// Function to get today's schedules from the database
function getTodaysSchedules($conn) {
    $sql = "SELECT * FROM waste_collection_assignments WHERE collection_date = CURDATE() ORDER BY id ASC";
    return $conn->query($sql);
}

// Function to update schedule status
function updateScheduleStatus($conn, $scheduleId, $status) {
    $validStatuses = ['pending', 'cancelled', 'in-progress', 'completed'];
    if (in_array($status, $validStatuses)) {
        $sql = "UPDATE waste_collection_assignments SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('si', $status, $scheduleId);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }
    return false;
}

// Handle AJAX status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $scheduleId = $_POST['schedule_id'];
    $status = $_POST['status'];
    $statusUpdated = updateScheduleStatus($conn, $scheduleId, $status);
    echo json_encode(['success' => $statusUpdated]);
    exit;
}

$schedules = getTodaysSchedules($conn);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Today's Schedules</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7fdf7;
            color: #2f855a;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #38a169;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
        }

        section {
            padding: 20px;
        }

        h2 {
            color: #2f855a;
            font-size: 26px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #e2e8b5;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #38a169;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f4fdf4;
        }

        tr:hover {
            background-color: #e0f7e0;
        }

        select {
            padding: 5px;
            border: 1px solid #38a169;
            background-color: #f7fdf7;
            color: #38a169;
            font-size: 14px;
        }

        button {
            background-color: #38a169;
            color: white;
            border: none;
            padding: 8px 16px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 4px;
        }

        button:hover {
            background-color: #2f855a;
        }

        .swal2-popup {
            background-color: #38a169;
            color: white;
        }

        .swal2-confirm {
            background-color: #2f855a;
            color: white;
        }

        .swal2-cancel {
            background-color: #e53e3e;
            color: white;
        }
    </style>
</head>
<body>

<div class="header">Today's Schedules</div>

<section>
    <h2>Today's Waste Collection Assignments</h2>
    <table>
        <thead>
            <tr>
                <th>Assign Day</th>
                <th>Date</th>
                <th>Area</th>
                <th>Waste Type</th>
                <th>Truck ID</th>
                <th>Driver ID</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($schedules && $schedules->num_rows > 0): ?>
            <?php while ($row = $schedules->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['assign_day']); ?></td>
                    <td><?= htmlspecialchars($row['collection_date']); ?></td>
                    <td><?= htmlspecialchars($row['area']); ?></td>
                    <td><?= htmlspecialchars($row['waste_type']); ?></td>
                    <td><?= htmlspecialchars($row['truck_id']); ?></td>
                    <td><?= htmlspecialchars($row['driver_id']); ?></td>
                    <td><?= ucfirst(htmlspecialchars($row['status'])); ?></td>
                    <td>
                        <form id="updateStatusForm<?= $row['id']; ?>">
                            <input type="hidden" name="schedule_id" value="<?= $row['id']; ?>">
                            <select name="status">
                                <option value="pending" <?= $row['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="cancelled" <?= $row['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                <option value="in-progress" <?= $row['status'] === 'in-progress' ? 'selected' : ''; ?>>In Progress</option>
                                <option value="completed" <?= $row['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                            <button type="button" onclick="showSweetAlert(event, <?= $row['id']; ?>)">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8" style="text-align:center;">No schedules for today.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</section>

<script>
function showSweetAlert(event, scheduleId) {
    event.preventDefault();

    const form = document.getElementById('updateStatusForm' + scheduleId);
    const status = form.querySelector('select[name="status"]').value;

    Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to update the status to "${status}"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#38a169',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, update it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData(form);
            formData.append('update_status', true);

            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Updated!',
                        text: 'Schedule status updated successfully.',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => location.reload());
                } else {
                    Swal.fire('Error', 'Failed to update status.', 'error');
                }
            });
        }
    });
}
</script>

</body>
</html>
