<?php
session_start();

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "nan";

// Establish connection
$conn = new mysqli($servername, $username, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $password = trim($_POST['password']);
    $full_name = htmlspecialchars(trim($_POST['full_name']));
    $address = htmlspecialchars(trim($_POST['address']));
    $gender = $_POST['gender'];
    $contact_number = htmlspecialchars(trim($_POST['contact_number']));
    $birthdate = $_POST['birthdate'];
    $age = intval($_POST['age']); // Ensure age is an integer

    // Check if any field is empty
    if (empty($email) || empty($password) || empty($full_name) || empty($address) || empty($gender) || empty($contact_number) || empty($birthdate) || empty($age)) {
        header("Location: registers.php?error=empty_fields");
        exit();
    }

    // Check if email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: registers.php?error=invalid_email");
        exit();
    }

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if the email already exists (Use Prepared Statement)
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        header("Location: registers.php?error=email_exists");
        exit();
    }
    $stmt->close();

    // Insert new user (Use Prepared Statement)
    $stmt = $conn->prepare("INSERT INTO users (email, password, full_name, address, gender, contact_number, birthdate, age) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssi", $email, $hashed_password, $full_name, $address, $gender, $contact_number, $birthdate, $age);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: log_in.php?success=registered");
        exit();
    } else {
        $stmt->close();
        header("Location: registers.php?error=registration_failed");
        exit();
    }
}

// Close the database connection
$conn->close();
?>
