<?php
include 'db_connection.php';

// Get the POST data
$id = $_POST['id'];
$status = $_POST['status'];

// Prepare the update query
$sql = "UPDATE waste_collection_assignments SET status = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('si', $status, $id);

// Execute the update
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}

// Close the database connection
$stmt->close();
$conn->close();
?>
