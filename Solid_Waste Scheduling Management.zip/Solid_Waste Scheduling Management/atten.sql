CREATE TABLE monthly_attendance_summary (
    collector_id INT,
    month_year VARCHAR(7),  -- Format: YYYY-MM
    total_present INT DEFAULT 0,
    total_absent INT DEFAULT 0,
    PRIMARY KEY (collector_id, month_year)
);
