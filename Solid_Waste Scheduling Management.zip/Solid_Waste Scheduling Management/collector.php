<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Salt Production Management Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background-color: #f0fff4;
    }
    .header {
      background-color: #38a169;
      color: white;
      width: 122%;
    }
    .sidebar {
      position: fixed; /* Make the sidebar fixed */
      top: 0;
      left: 0;
      bottom: 0;
      width: 16rem;
      background-color: #276749;
      color: white;
      display: flex;
      flex-direction: column;
      padding-top: 1rem;
      overflow-y: auto; /* Enable vertical scrolling */
    }
    .sidebar a {
      display: block;
      padding: 0.75rem 1rem;
      border-bottom: 1px solid #2f855a;
      color: white;
      cursor: pointer;
    }
    .sidebar a:hover {
      background-color: #2f855a;
    }
    iframe {
      margin-left: 16rem; /* Make space for the fixed sidebar */
      width: 100%;
      height: calc(100vh - 4rem);
      border: none;
    }
    .logout-button {
      background-color: #e53e3e;
      color: white;
      padding: 1rem;
      width: 100%;
      text-align: center;
      cursor: pointer;
    }
    .logout-button:hover {
      background-color: #c53030;
    }
  </style>
</head>
<body class="font-sans">
  <div class="flex h-screen">
    <!-- Sidebar -->
    <nav class="sidebar">
      <h2 class="text-2xl font-semibold mb-4 text-center">Waste Collector Portal</h2>
      <a onclick="loadPage('admin_dash.php')">Dashboard</a>
      <a onclick="loadPage('salt_batches.php')">Toaday Schedule</a>
      <a onclick="loadPage('scheduling.php')">Today Collectors</a>
      <a onclick="loadPage('analytics.php')">Attendance</a>
      <a onclick="loadPage('three_button.php')">Notification Center</a>
      <a onclick="loadPage('tools.php')">History and Performance Tracking</a>
    
      <!-- Logout Button at the bottom of the sidebar -->
      <div class="mt-auto">
        <div class="logout-button" onclick="confirmLogout()">🔒 Logout</div>
      </div>
    </nav>

    <!-- Main Content Area -->
    <div class="flex-1">
      <header class="header p-4 text-2xl font-semibold shadow text-center">
        🌿 Salt Production Management Portal
      </header>
      <iframe id="contentFrame" src="dashboard.php"></iframe>
    </div>
  </div>

  <script>
    function loadPage(page) {
      document.getElementById('contentFrame').src = page;
    }

    function confirmLogout() {
      Swal.fire({
        title: 'Are you sure?',
        text: "You will be logged out!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, logout!',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#e53e3e',
        cancelButtonColor: '#4CAF50',
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect to logout page or perform logout action
          window.location.href = 'logout.php'; // Replace with your actual logout action
        }
      });
    }
  </script>
</body>
</html>
