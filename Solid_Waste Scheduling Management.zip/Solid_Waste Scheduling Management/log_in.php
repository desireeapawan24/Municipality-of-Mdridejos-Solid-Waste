<?php
session_start();


$error = isset($_GET['error']) ? $_GET['error'] : '';
$success = isset($_GET['success']) ? $_GET['success'] : '';
$lockout_time = isset($_SESSION['lockout_time']) ? $_SESSION['lockout_time'] : 0;
$remaining_time = max(0, $lockout_time - time()); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 
    <style>
    body {
      background: linear-gradient(135deg, #68d391, #38a169);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      font-family: 'Poppins', sans-serif;
    }
    .container {
      background: #f0fff4;
      border-radius: 16px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
      padding: 40px;
      width: 380px;
      text-align: center;
    }
    h2 {
      font-family: 'Montserrat', sans-serif;
      font-size: 30px;
      color: #22543d;
      margin-bottom: 25px;
    }
    .input-container {
      width: 95%;
      margin-bottom: 18px;
    }
    .input-container input {
      width: 100%;
      padding: 14px;
      border: 2px solid #48bb78;
      border-radius: 10px;
      font-size: 16px;
      background: #ffffff;
      text-align: center;
      color: #2f855a;
    }
    button {
      background-color: #38a169;
      color: white;
      padding: 14px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-size: 18px;
      width: 100%;
      transition: 0.3s;
      margin-top: 15px;
    }
    button:hover {
      background-color: #2f855a;
    }
    button:disabled {
      background-color: gray;
      cursor: not-allowed;
    }
    .register-btn {
      background-color: transparent;
      color: #2b6cb0;
      font-size: 16px;
      padding: 12px;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.3s;
      text-decoration: none;
      display: inline-block;
      margin-top: 15px;
    }
    .register-btn:hover {
      background-color: rgba(66, 153, 225, 0.2);
    }
  </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>

        <form action="log_in_process.php" method="POST">
            <div class="input-container">
                <label for="email">Email:</label>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>
            <div class="input-container">
                <label for="password">Password:</label>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" id="loginButton" <?= ($remaining_time > 0) ? 'disabled' : ''; ?>>
                <?= ($remaining_time > 0) ? "Wait ($remaining_time s)" : "Login"; ?>
            </button>
        </form>

        <form action="registers.php" method="GET">
            <button type="submit" class="register-btn">Register</button>
        </form>
    </div>

    <script>
        let error = "<?= $error ?>";
        let success = "<?= $success ?>";
        let remainingTime = <?= $remaining_time ?>;
        let loginButton = document.getElementById("loginButton");

       
        if (error === "incorrect_password") {
            Swal.fire({
                icon: "error",
                title: "Incorrect Password",
                text: "You have " + (3 - <?= $_SESSION['failed_attempts'] ?? 0 ?>) + " attempts left.",
                confirmButtonColor: "#ff2d55"
            });
        } else if (error === "user_not_found") {
            Swal.fire({
                icon: "error",
                title: "User Not Found",
                text: "Please register first!",
                confirmButtonColor: "#ff2d55"
            });
        } else if (error === "empty_fields") {
            Swal.fire({
                icon: "error",
                title: "Empty Fields",
                text: "All fields are required.",
                confirmButtonColor: "#ff2d55"
            });
        } else if (error === "locked") {
            Swal.fire({
                icon: "error",
                title: "Account Locked",
                text: "Too many failed attempts. Please wait " + remainingTime + " seconds.",
                confirmButtonColor: "#ff2d55"
            });

            if (remainingTime > 0) {
                let countdown = setInterval(() => {
                    remainingTime--;
                    loginButton.innerText = "Wait (" + remainingTime + " s)";

                    if (remainingTime <= 0) {
                        clearInterval(countdown);
                        loginButton.disabled = false;
                        loginButton.innerText = "Login";
                        Swal.fire({
                            icon: "info",
                            title: "You can try logging in again.",
                            confirmButtonColor: "#ff2d55"
                        });
                    }
                }, 1000);
            }
        }

        if (success === "logged_in") {
            Swal.fire({
                icon: "success",
                title: "Login Successful!",
                text: "Redirecting to Dashboard...",
                confirmButtonColor: "#28a745",
                timer: 2000,
                showConfirmButton: false
            }).then(() => {
                window.location.href = "admin.php";
            });
        }
    </script>
</body>
</html>
