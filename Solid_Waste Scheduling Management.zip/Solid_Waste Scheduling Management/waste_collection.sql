CREATE TABLE IF NOT EXISTS waste_collections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    collection_date DATE NOT NULL,
    area VARCHAR(255) NOT NULL,
    waste_type VARCHAR(100) NOT NULL,
    status ENUM('pending', 'cancelled', 'in-progress', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);