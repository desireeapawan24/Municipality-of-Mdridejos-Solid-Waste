<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'nan';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Add Collector
if (isset($_POST['add_collector'])) {
    $full_name = $_POST['full_name'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $assign = $_POST['assign'];
    $role = $_POST['role'];
    $start_work_date = $_POST['start_work_date']; // Get the start work date

    // Validate required fields
    if (empty($full_name) || empty($contact_number) || empty($email) || empty($start_work_date)) {
        echo 'Error: All fields are required.';
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO waste_collectors (full_name, contact_number, email, assign, role, start_work_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $full_name, $contact_number, $email, $assign, $role, $start_work_date);
    $stmt->execute();
    echo 'Collector added successfully';
    exit;
}

// Handle Edit Collector
if (isset($_POST['edit_collector'])) {
    $collector_id = $_POST['collector_id'];
    $full_name = $_POST['full_name'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $assign = $_POST['assign'];
    $role = $_POST['role'];
    $start_work_date = $_POST['start_work_date']; // Get the start work date

    // Validate required fields
    if (empty($full_name) || empty($contact_number) || empty($email) || empty($start_work_date)) {
        echo 'Error: All fields are required.';
        exit;
    }

    $stmt = $conn->prepare("UPDATE waste_collectors SET full_name = ?, contact_number = ?, email = ?, assign = ?, role = ?, start_work_date = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $full_name, $contact_number, $email, $assign, $role, $start_work_date, $collector_id);
    $stmt->execute();
    echo 'Collector updated successfully';
    exit;
}

// Handle Delete Collector
if (isset($_POST['delete_collector'])) {
    $collector_id = $_POST['collector_id'];
    $stmt = $conn->prepare("DELETE FROM waste_collectors WHERE id = ?");
    $stmt->bind_param("i", $collector_id);
    $stmt->execute();
    echo 'Collector deleted successfully';
    exit;
}

// Handle Load Collectors
if (isset($_POST['load_collectors'])) {
    $result = $conn->query("SELECT * FROM waste_collectors");
    $collectors = [];
    while ($row = $result->fetch_assoc()) {
        $collectors[] = $row;
    }
    echo json_encode($collectors);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Waste Collector Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: #388e3c;
        }
        button {
            background-color: #388e3c;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-bottom: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #2e7d32;
        }
        .delete-btn {
            background-color: #c62828;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #2e7d32;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #2e7d32;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f1f8e9;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Waste Collector Management</h1>
    <button onclick="showAddCollectorForm()">Add Waste Collector</button>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Contact Number</th>
                <th>Email</th>
                <th>Assign</th>
                <th>Role</th>
                <th>Start Work Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="collectors-table-body">
            <!-- Dynamic content will be loaded here -->
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Function to load collectors from the database
    function loadCollectors() {
        fetch('admin_collec.php', {
            method: 'POST',
            body: new URLSearchParams({
                load_collectors: true
            })
        })
        .then(response => response.json())
        .then(collectors => {
            const tableBody = document.getElementById('collectors-table-body');
            tableBody.innerHTML = '';
            collectors.forEach(collector => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${collector.id}</td>
                    <td>${collector.full_name}</td>
                    <td>${collector.contact_number}</td>
                    <td>${collector.email}</td>
                    <td>${collector.assign}</td>
                    <td>${collector.role}</td>
                    <td>${collector.start_work_date}</td>
                    <td>
                        <button onclick="showEditCollectorForm(${collector.id}, '${collector.full_name}', '${collector.contact_number}', '${collector.email}', '${collector.assign}', '${collector.role}', '${collector.start_work_date}')">Edit</button>
                        <button class="delete-btn" onclick="deleteCollector(${collector.id})">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading collectors:', error));
    }

    // Function to show the Add Collector form
    function showAddCollectorForm() {
        Swal.fire({
            title: 'Add Waste Collector',
            html: ` 
                <input type="text" id="full_name" class="swal2-input" placeholder="Full Name">
                <input type="text" id="contact_number" class="swal2-input" placeholder="Contact Number">
                <input type="email" id="email" class="swal2-input" placeholder="Email">
                <select id="assign" class="swal2-input">
                    <option value="MWF">MWF</option>
                    <option value="TTHS">TTHS</option>
                </select>
                <select id="role" class="swal2-input">
                    <option value="Collector">Collector</option>
                    <option value="Driver">Driver</option>
                </select>
                <input type="date" id="start_work_date" class="swal2-input" placeholder="Start Work Date">
            `,
            preConfirm: () => {
                const full_name = document.getElementById('full_name').value;
                const contact_number = document.getElementById('contact_number').value;
                const email = document.getElementById('email').value;
                const assign = document.getElementById('assign').value;
                const role = document.getElementById('role').value;
                const start_work_date = document.getElementById('start_work_date').value;

                // Validate input fields
                if (!full_name || !contact_number || !email || !start_work_date) {
                    Swal.showValidationMessage('All fields are required');
                    return false;
                }

                // Send data to PHP script
                return fetch('admin_collec.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        add_collector: true,
                        full_name,
                        contact_number,
                        email,
                        assign,
                        role,
                        start_work_date
                    })
                })
                .then(response => response.text())
                .then(message => {
                    Swal.fire('Success', message, 'success');
                    loadCollectors();
                })
                .catch(error => {
                    Swal.fire('Error', 'Failed to add collector', 'error');
                    console.error('Error adding collector:', error);
                });
            }
        });
    }

    // Function to show the Edit Collector form
    function showEditCollectorForm(id, full_name, contact_number, email, assign, role, start_work_date) {
        Swal.fire({
            title: 'Edit Waste Collector',
            html: ` 
                <input type="hidden" id="collector_id" value="${id}">
                <input type="text" id="full_name" class="swal2-input" value="${full_name}" placeholder="Full Name">
                <input type="text" id="contact_number" class="swal2-input" value="${contact_number}" placeholder="Contact Number">
                <input type="email" id="email" class="swal2-input" value="${email}" placeholder="Email">
                <select id="assign" class="swal2-input">
                    <option value="MWF" ${assign === 'MWF' ? 'selected' : ''}>MWF</option>
                    <option value="TTHS" ${assign === 'TTHS' ? 'selected' : ''}>TTHS</option>
                </select>
                <select id="role" class="swal2-input">
                    <option value="Collector" ${role === 'Collector' ? 'selected' : ''}>Collector</option>
                    <option value="Driver" ${role === 'Driver' ? 'selected' : ''}>Driver</option>
                </select>
                <input type="date" id="start_work_date" class="swal2-input" value="${start_work_date}">
            `,
            preConfirm: () => {
                const collector_id = document.getElementById('collector_id').value;
                const full_name = document.getElementById('full_name').value;
                const contact_number = document.getElementById('contact_number').value;
                const email = document.getElementById('email').value;
                const assign = document.getElementById('assign').value;
                const role = document.getElementById('role').value;
                const start_work_date = document.getElementById('start_work_date').value;

                // Validate input fields
                if (!full_name || !contact_number || !email || !start_work_date) {
                    Swal.showValidationMessage('All fields are required');
                    return false;
                }

                // Send data to PHP script
                return fetch('admin_collec.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        edit_collector: true,
                        collector_id,
                        full_name,
                        contact_number,
                        email,
                        assign,
                        role,
                        start_work_date
                    })
                })
                .then(response => response.text())
                .then(message => {
                    Swal.fire('Success', message, 'success');
                    loadCollectors();
                })
                .catch(error => {
                    Swal.fire('Error', 'Failed to edit collector', 'error');
                    console.error('Error editing collector:', error);
                });
            }
        });
    }

    // Function to delete a collector
    function deleteCollector(id) {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('admin_collec.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        delete_collector: true,
                        collector_id: id
                    })
                })
                .then(response => response.text())
                .then(message => {
                    Swal.fire('Deleted!', message, 'success');
                    loadCollectors();
                })
                .catch(error => {
                    Swal.fire('Error', 'Failed to delete collector', 'error');
                    console.error('Error deleting collector:', error);
                });
            }
        });
    }

    // Load collectors initially
    loadCollectors();
</script>
</body>
</html>
