<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Attendance Summary</title>
    <style>
        /* Base theme color */
        body {
            font-family: Arial, sans-serif;
            background-color: #e9f7ef; /* Light green background */
            color: #2f6d4e; /* Dark green text */
            padding: 20px;
        }

        h2 {
            color: #4caf50; /* Lively green color for the heading */
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffff;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #d1e7d1; /* Light green border */
        }

        th {
            background-color: #81c784; /* Lively green for headers */
            color: white;
        }

        table td, table th {
            border-color: #81c784;
        }
    </style>
</head>
<body>

    <h2>Monthly Attendance Summary for <?php echo date('Y-m'); ?></h2>

    <table id="attendance-table">
        <thead>
            <tr>
                <th>Collector</th>
                <th>Total Present</th>
                <th>Total Absent</th>
            </tr>
        </thead>
        <tbody>
            <!-- Data will be populated here by AJAX -->
        </tbody>
    </table>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function loadAttendanceData() {
            $.ajax({
                url: 'fetch_attendance.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    var tableBody = $('#attendance-table tbody');
                    tableBody.empty(); // Clear the existing table data

                    // Append new data to the table
                    data.forEach(function(row) {
                        var newRow = '<tr>';
                        newRow += '<td>' + row.full_name + '</td>';
                        newRow += '<td>' + row.total_present + '</td>';
                        newRow += '<td>' + row.total_absent + '</td>';
                        newRow += '</tr>';
                        tableBody.append(newRow);
                    });
                },
                error: function() {
                    alert('Failed to fetch attendance data.');
                }
            });
        }

        // Load attendance data every 5 seconds
        setInterval(loadAttendanceData, 5000);
        loadAttendanceData(); // Initial load on page load
    </script>

</body>
</html>
