CREATE TABLE IF NOT EXISTS collector_trucks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    truck_number VARCHAR(50) UNIQUE NOT NULL,
    plate_number VARCHAR(50) UNIQUE NOT NULL
);
