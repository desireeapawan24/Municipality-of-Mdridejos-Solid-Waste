<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST['id']);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $gender = trim($_POST['gender']);
    $contact_number = trim($_POST['contact_number']);
    $birthdate = trim($_POST['birthdate']);

    // Validate fields
    if (empty($full_name) || empty($email) || empty($address) || empty($contact_number) || empty($birthdate) || empty($gender)) {
        echo json_encode(["status" => "error", "message" => "All fields are required"]);
        exit();
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Invalid email format"]);
        exit();
    }

    // Calculate age
    $birthdateObj = new DateTime($birthdate);
    $today = new DateTime();
    $age = $today->diff($birthdateObj)->y;

    // Update user data
    $stmt = $conn->prepare("UPDATE users SET full_name=?, email=?, address=?, gender=?, contact_number=?, birthdate=?, age=? WHERE id=?");
    $stmt->bind_param("ssssssii", $full_name, $email, $address, $gender, $contact_number, $birthdate, $age, $id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User updated successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update user"]);
    }

    $stmt->close();
    $conn->close();
}
?>
