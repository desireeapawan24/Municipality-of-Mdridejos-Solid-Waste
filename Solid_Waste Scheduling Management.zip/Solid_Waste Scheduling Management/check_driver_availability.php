<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $driverId = $_POST['driver_id'];
    $collectionDate = $_POST['collection_date'];

    // Check if the driver is already assigned on the same date
    $sql = "SELECT * FROM waste_collection_assignments WHERE driver_id = ? AND collection_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $driverId, $collectionDate);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Driver is already assigned
        echo json_encode(['success' => false, 'message' => 'This driver is already assigned on the selected date.']);
    } else {
        // Driver is available
        echo json_encode(['success' => true, 'message' => 'Driver is available.']);
    }

    $stmt->close();
    $conn->close();
}
?>
