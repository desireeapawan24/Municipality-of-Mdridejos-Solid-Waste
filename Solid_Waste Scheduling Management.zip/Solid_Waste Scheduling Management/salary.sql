CREATE TABLE collector_salaries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    collector_id INT NOT NULL,             -- Foreign key referencing waste_collectors table
    salary DECIMAL(10, 2) NOT NULL,        -- Salary field with 2 decimal places
    FOREIGN KEY (collector_id) REFERENCES waste_collectors(id)  -- Foreign key constraint
);
