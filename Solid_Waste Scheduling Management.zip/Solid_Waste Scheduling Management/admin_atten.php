<?php
// Include the database connection
include 'db_connect.php';

// Get current month and year (YYYY-MM)
$current_month_year = date('Y-m');

// Fetch attendance summary + salary
$summary_sql = "
    SELECT c.full_name, 
           COUNT(ca.id) AS total_present,
           DATEDIFF(CURDATE(), c.start_work_date) AS days_worked,
           cs.salary
    FROM waste_collectors c
    LEFT JOIN collector_attendance ca 
        ON c.id = ca.collector_id 
        AND ca.status = 'Present'
        AND DATE_FORMAT(ca.attendance_date, '%Y-%m') = ?
    LEFT JOIN collector_salaries cs 
        ON cs.collector_id = c.id
    GROUP BY c.id
";
$summary_stmt = $conn->prepare($summary_sql);
$summary_stmt->bind_param('s', $current_month_year);
$summary_stmt->execute();
$summary_result = $summary_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Attendance Summary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9f7ef;
            color: #2f6d4e;
            padding: 20px;
        }

        h2 {
            color: #4caf50;
            text-align: center;
        }

        .print-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px auto;
            display: block;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffff;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #d1e7d1;
        }

        th {
            background-color: #81c784;
            color: white;
        }

        td.salary, td.total-salary {
            font-weight: bold;
            color: #1b5e20;
        }

        @media print {
            .print-btn {
                display: none;
            }

            body {
                background-color: white;
                color: black;
            }

            table {
                page-break-after: always;
            }
        }
    </style>
</head>
<body>

    <h2>Monthly Attendance Summary for <?php echo $current_month_year; ?></h2>

    <button class="print-btn" onclick="window.print()">🖨️ Print Payroll</button>

    <table>
        <thead>
            <tr>
                <th>Collector</th>
                <th>Total Present</th>
                <th>Start Worked</th>
                <th>Daily Salary</th>
                <th>Total Salary</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($summary = $summary_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $summary['full_name']; ?></td>
                    <td><?php echo $summary['total_present']; ?></td>
                    <td>
                        <?php 
                            $days_worked = $summary['days_worked'];
                            $years = floor($days_worked / 365);
                            $weeks = floor($days_worked / 7);
                            $remaining_days = $days_worked % 7;

                            if ($years > 0) {
                                echo "$years year" . ($years > 1 ? 's' : '');
                            } elseif ($weeks > 0) {
                                echo "$weeks week" . ($weeks > 1 ? 's' : '') . " and $remaining_days day" . ($remaining_days > 1 ? 's' : '');
                            } else {
                                echo "$days_worked day" . ($days_worked > 1 ? 's' : '');
                            }
                        ?>
                    </td>
                    <td class="salary">
                        <?php 
                            echo $summary['salary'] !== null 
                                ? "₱" . number_format($summary['salary'], 2) 
                                : 'Not Set'; 
                        ?>
                    </td>
                    <td class="total-salary">
                        <?php 
                            if ($summary['salary'] !== null) {
                                $total_salary = $summary['total_present'] * $summary['salary'];
                                echo "₱" . number_format($total_salary, 2);
                            } else {
                                echo 'Not Set';
                            }
                        ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</body>
</html>
