CREATE TABLE collector_attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    collector_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present', 'Absent') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (collector_id) REFERENCES waste_collectors(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_attendance (collector_id, attendance_date)
);
