<?php
// Include database connection
include 'db_connection.php';

// Check if form data is posted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $truck_number = $_POST['truck_number'];
    $plate_number = $_POST['plate_number'];

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO collector_trucks (truck_number, plate_number) VALUES (?, ?)");
    $stmt->bind_param("ss", $truck_number, $plate_number);  // 'ss' means both are strings

    // Execute the query
    if ($stmt->execute()) {
        // If successful, return a success message
        echo json_encode(['success' => true, 'message' => 'Truck added successfully!']);
    } else {
        // If there is an error, return an error message
        echo json_encode(['success' => false, 'message' => 'Error adding truck: ' . $stmt->error]);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // Return an error if the request is not POST
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
