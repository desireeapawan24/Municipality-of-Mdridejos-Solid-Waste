<?php
session_start();
include 'db_connection.php'; // Ensure this file contains the DB connection

// Check if user is locked out
if (isset($_SESSION['lockout_time']) && time() < $_SESSION['lockout_time']) {
    header("Location: log_in.php?error=locked");
    exit();
}

// Initialize failed attempts count if not set
if (!isset($_SESSION['failed_attempts'])) {
    $_SESSION['failed_attempts'] = 0;
}

// Get user input and sanitize
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$password = trim($_POST['password'] ?? '');

// Check for empty fields
if (empty($email) || empty($password)) {
    header("Location: log_in.php?error=empty_fields");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "nan"); // Ensure credentials are correct

// Check for connection errors
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch user details using prepared statement
$stmt = $conn->prepare("SELECT id, full_name, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// If user not found
if (!$user) {
    $_SESSION['failed_attempts']++;
    checkLockout();
    header("Location: log_in.php?error=user_not_found");
    exit();
}

// Verify password securely
if (!password_verify($password, $user['password'])) {
    $_SESSION['failed_attempts']++;
    checkLockout();
    header("Location: log_in.php?error=incorrect_password");
    exit();
}

// Successful login: Reset failed attempts and start session
$_SESSION['user_id'] = $user['id'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['failed_attempts'] = 0; // Reset failed attempts

header("Location: admin.php");
exit();

/**
 * Check for lockout and handle it
 */
function checkLockout()
{
    if ($_SESSION['failed_attempts'] >= 3) {
        $_SESSION['lockout_time'] = time() + 60; // Lock for 1 minute
        $_SESSION['failed_attempts'] = 0; // Reset failed attempts after lockout
        header("Location: log_in.php?error=locked");
        exit();
    }
}
?>
