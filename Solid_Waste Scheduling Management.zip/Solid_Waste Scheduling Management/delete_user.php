<?php
session_start();
include 'db.php';

header('Content-Type: application/json');

if (!isset($_POST['id'])) {
    echo json_encode(["success" => false, "error" => "User ID is missing."]);
    exit();
}

$id = intval($_POST['id']);

$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => "Failed to delete user."]);
}

$stmt->close();
$conn->close();
?>
