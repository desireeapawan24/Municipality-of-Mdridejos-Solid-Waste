<?php
include 'db.php';

$attendance_date = date('Y-m-d');
$current_month_year = date('Y-m');
$day_of_week = date('D');

$assign_group = match ($day_of_week) {
    'Mon', 'Wed', 'Fri' => 'MWF',
    'Tue', 'Thu', 'Sat' => 'TTHS',
    default => null
};

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $assign_group) {
    foreach ($_POST['attendance_status'] as $collector_id => $status) {
        // Check if attendance already exists
        $check_sql = "SELECT * FROM collector_attendance WHERE collector_id = ? AND attendance_date = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param('is', $collector_id, $attendance_date);
        $stmt->execute();
        $result = $stmt->get_result();

        $totals = [
            'Present' => [1, 0],
            'Absent' => [0, 1],
        ];
        [$p, $a] = $totals[$status] ?? [0, 0];

        if ($result->num_rows == 0) {
            // Insert new attendance
            $insert_stmt = $conn->prepare("INSERT INTO collector_attendance (collector_id, attendance_date, status) VALUES (?, ?, ?)");
            $insert_stmt->bind_param('iss', $collector_id, $attendance_date, $status);
            $insert_stmt->execute();

            // Insert or update summary
            $summary_stmt = $conn->prepare("SELECT * FROM monthly_attendance_summary WHERE collector_id = ? AND month_year = ?");
            $summary_stmt->bind_param('is', $collector_id, $current_month_year);
            $summary_stmt->execute();
            $summary_result = $summary_stmt->get_result();

            if ($summary_result->num_rows > 0) {
                $update = $conn->prepare("UPDATE monthly_attendance_summary 
                    SET total_present = total_present + ?, total_absent = total_absent + ?
                    WHERE collector_id = ? AND month_year = ?");
                $update->bind_param('iiis', $p, $a, $collector_id, $current_month_year);
                $update->execute();
            } else {
                $insert_summary = $conn->prepare("INSERT INTO monthly_attendance_summary 
                    (collector_id, month_year, total_present, total_absent)
                    VALUES (?, ?, ?, ?)");
                $insert_summary->bind_param('isii', $collector_id, $current_month_year, $p, $a);
                $insert_summary->execute();
            }
        } else {
            // Update attendance
            $existing_row = $result->fetch_assoc();
            $prev_status = $existing_row['status'];

            if ($prev_status !== $status) {
                // Update attendance record
                $update_attendance = $conn->prepare("UPDATE collector_attendance SET status = ? WHERE collector_id = ? AND attendance_date = ?");
                $update_attendance->bind_param('sis', $status, $collector_id, $attendance_date);
                $update_attendance->execute();

                // Adjust monthly summary
                $adjustments = [
                    'Present' => [1, -1],
                    'Absent' => [-1, 1],
                ];
                $prev_adjust = $adjustments[$prev_status] ?? [0, 0];
                $new_adjust = $adjustments[$status] ?? [0, 0];

                $present_adjust = $new_adjust[0] - $prev_adjust[0];
                $absent_adjust = $new_adjust[1] - $prev_adjust[1];

                $update_summary = $conn->prepare("UPDATE monthly_attendance_summary 
                    SET total_present = total_present + ?, total_absent = total_absent + ?
                    WHERE collector_id = ? AND month_year = ?");
                $update_summary->bind_param('iiis', $present_adjust, $absent_adjust, $collector_id, $current_month_year);
                $update_summary->execute();
            }
        }
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Waste Collector Attendance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: url('images/tanduay-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            padding: 40px;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(5px);
        }
        .status-badge {
            font-size: 0.85rem;
            padding: 0.4em 0.6em;
            border-radius: 12px;
        }
    </style>
</head>
<body>

<div class="container p-4 rounded shadow">
    <h2 class="text-center mb-4 text-success">Today's Attendance (<?= $assign_group ?? 'N/A' ?>)</h2>

    <?php if ($assign_group): ?>
    <form method="POST">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead class="table-success">
                <tr>
                    <th>Full Name</th>
                    <th>Role</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $stmt = $conn->prepare("SELECT id, full_name, role FROM waste_collectors WHERE assign = ?");
            $stmt->bind_param('s', $assign_group);
            $stmt->execute();
            $collectors = $stmt->get_result();

            $statuses = ['Present' => 'success', 'Absent'  => 'info'];

            while ($row = $collectors->fetch_assoc()):
                $check = $conn->prepare("SELECT status FROM collector_attendance WHERE collector_id = ? AND attendance_date = ?");
                $check->bind_param('is', $row['id'], $attendance_date);
                $check->execute();
                $existing = $check->get_result()->fetch_assoc();
                $current_status = $existing['status'] ?? '';
            ?>
                <tr>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= htmlspecialchars($row['role']) ?></td>
                    <td>
                        <?php foreach ($statuses as $label => $color): ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="attendance_status[<?= $row['id'] ?>]"
                                       id="<?= $label . $row['id'] ?>" value="<?= $label ?>"
                                       <?= ($current_status === $label) ? 'checked' : '' ?>>
                                <label class="form-check-label badge bg-<?= $color ?> status-badge"
                                       for="<?= $label . $row['id'] ?>"><?= $label ?></label>
                            </div>
                        <?php endforeach; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        <div class="text-center">
            <button type="submit" class="btn btn-success btn-lg">Submit Attendance</button>
        </div>
    </form>
    <?php else: ?>
        <div class="alert alert-danger text-center fw-bold">No attendance allowed today (Sunday or unassigned).</div>
    <?php endif; ?>
</div>

<?php if (isset($_GET['success'])): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Attendance Saved',
        text: 'Attendance entries have been saved or updated successfully!',
        confirmButtonColor: '#28a745'
    });
</script>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
