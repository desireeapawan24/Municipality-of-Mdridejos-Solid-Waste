<?php
include 'db_conn.php'; // Your DB connection

$date_today = date("Y-m-d");
$current_month = date("Y-m");

// Summary stats queries
$sql_total_collectors = "SELECT COUNT(*) AS total FROM waste_collectors WHERE role = 'Collector'";
$total_collectors = $conn->query($sql_total_collectors)->fetch_assoc()['total'] ?? 0;

$sql_total_drivers = "SELECT COUNT(*) AS total FROM waste_collectors WHERE role = 'Driver'";
$total_drivers = $conn->query($sql_total_drivers)->fetch_assoc()['total'] ?? 0;

$sql_today_attendance = "SELECT 
    SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
    SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent
    FROM collector_attendance WHERE attendance_date = '$date_today'";
$today_attendance = $conn->query($sql_today_attendance)->fetch_assoc();
$present_today = $today_attendance['present'] ?? 0;
$absent_today = $today_attendance['absent'] ?? 0;

$sql_total_trucks = "SELECT COUNT(*) AS total FROM collector_trucks";
$total_trucks = $conn->query($sql_total_trucks)->fetch_assoc()['total'] ?? 0;

$sql_total_mwf = "SELECT COUNT(*) AS total FROM waste_collection_assignments WHERE assign_day = 'MWF'";
$total_mwf = $conn->query($sql_total_mwf)->fetch_assoc()['total'] ?? 0;

$sql_total_tths = "SELECT COUNT(*) AS total FROM waste_collection_assignments WHERE assign_day = 'TTHS'";
$total_tths = $conn->query($sql_total_tths)->fetch_assoc()['total'] ?? 0;

$sql_areas_today = "SELECT DISTINCT area FROM waste_collection_assignments WHERE collection_date = '$date_today'";
$result_areas = $conn->query($sql_areas_today);
$areas_today = [];
while ($row = $result_areas->fetch_assoc()) {
    $areas_today[] = $row['area'];
}

// Monthly attendance per collector
$sql_monthly_attendance = "SELECT 
    wc.full_name AS collector_name, 
    SUM(CASE WHEN ca.status = 'Present' THEN 1 ELSE 0 END) AS present,
    SUM(CASE WHEN ca.status = 'Absent' THEN 1 ELSE 0 END) AS absent 
    FROM collector_attendance ca
    JOIN waste_collectors wc ON ca.collector_id = wc.id
    WHERE ca.attendance_date LIKE '$current_month%' 
    GROUP BY wc.full_name";
$result_monthly_attendance = $conn->query($sql_monthly_attendance);
$monthly_attendance = [];
while ($row = $result_monthly_attendance->fetch_assoc()) {
    $monthly_attendance[] = $row;
}

// Assignments per truck
$sql_truck_assignments = "SELECT truck_id, COUNT(*) AS total_assignments FROM waste_collection_assignments GROUP BY truck_id";
$result_truck_assignments = $conn->query($sql_truck_assignments);
$truck_labels = [];
$truck_data = [];
while ($row = $result_truck_assignments->fetch_assoc()) {
    $truck_labels[] = "Truck " . $row['truck_id'];
    $truck_data[] = (int)$row['total_assignments'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Waste Collection Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background: #e8f5e9;
        margin: 0; padding: 0;
    }
    h1 {
        text-align: center;
        margin: 30px 0;
        color: #2e7d32;
    }
    .dashboard {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        padding: 20px 40px;
    }
    .card {
        background: #a8e6cf;
        padding: 20px;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 0 12px rgba(0, 100, 0, 0.15);
        transition: transform 0.3s ease;
    }
    .card:hover {
        transform: scale(1.03);
    }
    .card p {
        font-size: 18px;
        color: #075e54;
        margin: 0;
    }
    .card h2 {
        font-size: 36px;
        color: #004d40;
        margin-top: 10px;
    }
    .area-list {
        text-align: left;
        font-size: 16px;
        color: #075e54;
        margin-top: 10px;
    }
    .area-list ul {
        padding-left: 20px;
        margin: 0;
    }
    .charts-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 20px 40px 40px;
    }
    .chart-card {
        background: #a8e6cf;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 0 12px rgba(0, 100, 0, 0.15);
        height: 360px;
    }
    .chart-card p {
        text-align: center;
        font-weight: bold;
        margin-bottom: 15px;
        color: #2e7d32;
    }
    canvas {
        width: 100% !important;
        height: 280px !important;
    }
</style>
</head>
<body>
<h1>Waste Collection Dashboard</h1>

<div class="dashboard">
    <div class="card"><p>Total Collectors</p><h2><?= $total_collectors ?></h2></div>
    <div class="card"><p>Total Drivers</p><h2><?= $total_drivers ?></h2></div>
    <div class="card"><p>Present Today</p><h2><?= $present_today ?></h2></div>
    <div class="card"><p>Absent Today</p><h2><?= $absent_today ?></h2></div>
    <div class="card"><p>Total Trucks</p><h2><?= $total_trucks ?></h2></div>
    <div class="card"><p>Assignments (MWF)</p><h2><?= $total_mwf ?></h2></div>
    <div class="card"><p>Assignments (TTHS)</p><h2><?= $total_tths ?></h2></div>
    <div class="card">
        <p>Areas Scheduled Today</p>
        <div class="area-list">
            <?php
            if ($areas_today) {
                echo "<ul>";
                foreach ($areas_today as $area) {
                    echo "<li>" . htmlspecialchars($area) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No areas scheduled for today.</p>";
            }
            ?>
        </div>
    </div>
</div>

<div class="charts-container">
    <div class="chart-card">
        <p>MWF vs TTHS Waste Collection Assignments</p>
        <canvas id="mwfTthsBarChart"></canvas>
    </div>

    <div class="chart-card">
        <p>Today's Attendance</p>
        <canvas id="todayAttendanceChart"></canvas>
    </div>
    <div class="chart-card">
        <p>Monthly Attendance Summary</p>
        <canvas id="monthlyAttendanceChart"></canvas>
    </div>
    <div class="chart-card">
        <p>Assignments per Truck</p>
        <canvas id="truckAssignmentsChart"></canvas>
    </div>
</div>

<script>
// Bar Chart for MWF vs TTHS
const mwfTthsCtx = document.getElementById('mwfTthsBarChart').getContext('2d');
const mwfTthsChart = new Chart(mwfTthsCtx, {
    type: 'bar',
    data: {
        labels: ['MWF', 'TTHS'],
        datasets: [{
            label: 'Assignments',
            data: [<?= $total_mwf ?>, <?= $total_tths ?>],
            backgroundColor: ['#388e3c', '#66bb6a']
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// Doughnut Chart for Today's Attendance
const todayAttendanceCtx = document.getElementById('todayAttendanceChart').getContext('2d');
const todayAttendanceChart = new Chart(todayAttendanceCtx, {
    type: 'doughnut',
    data: {
        labels: ['Present', 'Absent'],
        datasets: [{
            data: [<?= $present_today ?>, <?= $absent_today ?>],
            backgroundColor: ['#2e7d32', '#c62828']
        }]
    },
    options: {
        cutout: '70%'
    }
});

// Line Chart for Monthly Attendance Summary
const monthlyAttendanceCtx = document.getElementById('monthlyAttendanceChart').getContext('2d');
const monthlyLabels = <?= json_encode(array_column($monthly_attendance, 'collector_name')) ?>;
const monthlyPresent = <?= json_encode(array_column($monthly_attendance, 'present')) ?>;
const monthlyAbsent = <?= json_encode(array_column($monthly_attendance, 'absent')) ?>;

const monthlyAttendanceChart = new Chart(monthlyAttendanceCtx, {
    type: 'line',
    data: {
        labels: monthlyLabels,
        datasets: [
            {
                label: 'Present',
                data: monthlyPresent,
                borderColor: '#388e3c',
                backgroundColor: 'rgba(56, 142, 60, 0.2)',
                fill: true,
                tension: 0.3,
                pointRadius: 5,
                pointHoverRadius: 7,
                borderWidth: 3
            },
            {
                label: 'Absent',
                data: monthlyAbsent,
                borderColor: '#c62828',
                backgroundColor: 'rgba(198, 40, 40, 0.2)',
                fill: true,
                tension: 0.3,
                pointRadius: 5,
                pointHoverRadius: 7,
                borderWidth: 3
            }
        ]
    },
    options: {
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// Bar Chart for Assignments per Truck
const truckAssignmentsCtx = document.getElementById('truckAssignmentsChart').getContext('2d');
const truckAssignmentsChart = new Chart(truckAssignmentsCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($truck_labels) ?>,
        datasets: [{
            label: 'Assignments',
            data: <?= json_encode($truck_data) ?>,
            backgroundColor: '#66bb6a'
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

</body>
</html>
